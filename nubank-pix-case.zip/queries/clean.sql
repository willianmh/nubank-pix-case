use nubank;

DROP TABLE d_time;
DROP TABLE d_week;
DROP TABLE d_weekday;
DROP TABLE d_month;
DROP TABLE d_year;

DROP TABLE transfer_ins;
DROP TABLE transfer_outs;
DROP TABLE pix_movements;

DROP TABLE accounts;
DROP TABLE customers;

DROP TABLE city;
DROP TABLE state;
DROP TABLE country;
